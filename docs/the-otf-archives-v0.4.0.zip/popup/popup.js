// popup.js
//
// M2: renders the real inventory from chrome.storage.local. The popup runs in an extension
// page context, so it has direct chrome.storage access — it reads storage itself rather than
// depending on a shared helper script (loading lib/* across paths into a popup is brittle).
// Rendering is unchanged from M1 since it only depends on { name, rarity, icon }.

(function () {
  "use strict";

  const INVENTORY_KEY = "inventory";

  const RARITY_ORDER = ["legendary", "rare", "uncommon", "common"];
  const RARITY_LABEL = {
    legendary: "OTF History",
    rare: "Deep Lore",
    uncommon: "Touch Grass Moments",
    common: "Skill Issues",
  };

  // Read the inventory array directly from chrome.storage.local.
  // Resolves with the array; rejects on a genuine storage error so render() can show a
  // distinct error state (rather than silently masquerading as "no treasures yet").
  function loadInventory() {
    return new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        reject(new Error("chrome.storage.local unavailable"));
        return;
      }
      chrome.storage.local.get(INVENTORY_KEY, (res) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        const inv = res && Array.isArray(res[INVENTORY_KEY]) ? res[INVENTORY_KEY] : [];
        resolve(inv);
      });
    });
  }

  function groupByRarity(items) {
    const groups = {};
    for (const item of items) {
      (groups[item.rarity] = groups[item.rarity] || []).push(item);
    }
    return groups;
  }

  // Collapse duplicates within a rarity group into stacks.
  // Ancient and non-ancient are separate stacks.
  function stackItems(items) {
    const map = {};
    for (const item of items) {
      const stackKey = item.key + (item.ancient ? ":ancient" : "");
      if (map[stackKey]) {
        map[stackKey].count++;
      } else {
        map[stackKey] = Object.assign({}, item, { count: 1 });
      }
    }
    return Object.values(map);
  }

  async function render() {
    const root = document.getElementById("inventory");
    if (!root) return;
    root.textContent = "";

    let items;
    try {
      items = await loadInventory();
    } catch (e) {
      const err = document.createElement("p");
      err.className = "empty";
      err.textContent = "Couldn't load your collection. Try reopening the popup.";
      root.appendChild(err);
      return;
    }

    if (items.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        "<p class=\"empty__heading\">No lore collected yet.</p>" +
        "<ol class=\"empty__rules\">" +
        "<li>Keep clicking topics</li>" +
        "<li>The lore must grow</li>" +
        "<li>Inb4thelock</li>" +
        "</ol>" +
        "<p class=\"empty__fine\">Some topics hide treasure. Each can reward you once per week.<br>Older topics hide rarer treasure.</p>";
      root.appendChild(empty);
      return;
    }

    const groups = groupByRarity(items);

    for (const rarity of RARITY_ORDER) {
      const groupItems = groups[rarity];
      if (!groupItems || groupItems.length === 0) continue;

      const section = document.createElement("section");
      section.className = "rarity rarity--" + rarity;

      const heading = document.createElement("h2");
      heading.className = "rarity__title";
      heading.textContent =
        (RARITY_LABEL[rarity] || rarity) + " (" + groupItems.length + ")";
      section.appendChild(heading);

      const grid = document.createElement("div");
      grid.className = "grid";
      for (const item of stackItems(groupItems)) {
        grid.appendChild(renderCard(item));
      }
      section.appendChild(grid);
      root.appendChild(section);
    }
  }

  function renderCard(item) {
    const card = document.createElement("div");
    card.className =
      "card card--" + item.rarity + (item.ancient ? " card--ancient" : "");
    card.title = (item.ancient ? "Ancient " : "") + item.name;

    const icon = document.createElement("div");
    icon.className = "card__icon";
    icon.setAttribute("aria-hidden", "true");

    const imgEl = document.createElement("img");
    imgEl.src = "../assets/treasures/" + item.key + ".png";
    imgEl.alt = "";
    imgEl.className = "card__img";
    imgEl.onerror = function () {
      icon.removeChild(imgEl);
      icon.textContent = item.icon || "\u2727";
    };
    icon.appendChild(imgEl);

    const name = document.createElement("div");
    name.className = "card__name";
    name.textContent = item.name;

    card.appendChild(icon);
    if (item.count > 1) {
      const count = document.createElement("div");
      count.className = "card__count";
      count.textContent = "\u00d7" + item.count;
      card.appendChild(count);
    }
    if (item.ancient) {
      const badge = document.createElement("div");
      badge.className = "card__badge";
      badge.textContent = "Ancient";
      card.appendChild(badge);
    }
    card.appendChild(name);
    return card;
  }

  document.addEventListener("DOMContentLoaded", function () {
    render();

    // About modal.
    const aboutModal = document.getElementById("about-modal");
    const aboutBtn   = document.getElementById("about-btn");
    const aboutClose = document.getElementById("about-close");
    if (aboutBtn && aboutModal && aboutClose) {
      aboutBtn.addEventListener("click", function () {
        aboutModal.setAttribute("aria-hidden", "false");
      });
      aboutClose.addEventListener("click", function () {
        aboutModal.setAttribute("aria-hidden", "true");
        aboutBtn.focus();
      });
    }
  });
})();
