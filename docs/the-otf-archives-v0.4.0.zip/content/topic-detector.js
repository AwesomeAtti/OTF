// topic-detector.js
//
// The ONLY module that knows chess.com's DOM and URL shape. If chess.com changes
// its markup, this is the single file to update (see docs/research/topic-id-verification.md,
// B-002). Everything downstream depends only on the functions exposed here via
// window.ChessTreasureDetector.
//
// Detection rule (verified 2026-06-21):
//   - A page is a topic page when location.pathname matches /forum/view/<category>/<slug>.
//   - The award key is the numeric id in [data-forum-topic-id].
//   - Strip query/fragment from any URL-derived value.
//   - Fail safe: if the id can't be read, return null (caller awards nothing).

(function () {
  "use strict";

  // /forum/view/<category>/<slug> — at least two non-empty path segments after /forum/view.
  const TOPIC_PATH_RE = /^\/forum\/view\/[^/]+\/[^/]+\/?$/;

  // Selector for the element carrying the numeric topic id. Isolated here on purpose.
  const TOPIC_ID_SELECTOR = "[data-forum-topic-id]";
  const TOPIC_ID_ATTR = "data-forum-topic-id";

  /** True if the current page is an off-topic forum topic page. */
  function isTopicPage() {
    return TOPIC_PATH_RE.test(location.pathname);
  }

  /**
   * Read the stable numeric topic id from the DOM.
   * @returns {string|null} the id as a string, or null if unavailable (fail-safe).
   */
  function getTopicId() {
    const el = document.querySelector(TOPIC_ID_SELECTOR);
    if (!el) return null;
    const raw = el.getAttribute(TOPIC_ID_ATTR);
    if (!raw) return null;
    const trimmed = raw.trim();
    // Expect digits only; reject anything else rather than hashing junk.
    if (!/^\d+$/.test(trimmed)) return null;
    return trimmed;
  }

  /** Convenience: returns the id only when this is genuinely a topic page. */
  function resolveTopicId() {
    if (!isTopicPage()) return null;
    return getTopicId();
  }

  window.ChessTreasureDetector = { isTopicPage, getTopicId, resolveTopicId };
})();
