// content.js
//
// The real treasure mechanic (B-003 M2 + B-016 M3). On an off-topic topic page:
//   1. detector resolves a stable topicId (topic-detector.js, fail-safe).
//   2. period = current ISO week (lib/period.js, B-005).
//   3. if already claimed for topicId:period -> stop (award once).
//   4. read the topic age tier (lib/topic-age.js) and adjust odds (lib/rarity.js); older
//      topics get a better roll. Fail-safe: unknown age -> no bonus.
//   5. roll rarity deterministically; "nothing" -> stop silently.
//   6. pick a concrete treasure (lib/catalog.js), mark it "Ancient" if the topic is a
//      year+ old, persist it (lib/storage.js), and show a toast.
//
// All chess.com DOM knowledge stays in topic-detector.js and topic-age.js. Hash/rarity/
// period/catalog/storage are pure libs loaded before this file (see manifest order).

(function () {
  "use strict";

  const detector = window.ChessTreasureDetector;
  const Period = window.CTHPeriod;
  const Rarity = window.CTHRarity;
  const Catalog = window.CTHCatalog;
  const Storage = window.CTHStorage;
  const TopicAge = window.CTHTopicAge;

  // If any dependency failed to load, do nothing (fail-safe). TopicAge is optional: if it's
  // missing we simply award without the age bonus.
  if (!detector || !Period || !Rarity || !Catalog || !Storage) return;

  const topicId = detector.resolveTopicId();
  if (!topicId) return; // not a topic page, or id unreadable -> award nothing.

  const period = Period.periodKey();

  run(topicId, period);

  async function run(topicId, period) {
    try {
      if (await Storage.isClaimed(topicId, period)) return; // already awarded.

      // Age bonus (B-016): older topics get better odds. Fail-safe: unknown age -> no bonus.
      const ageTier = TopicAge ? TopicAge.getAgeTier() : null;
      const weights = Rarity.ageAdjustedWeights(ageTier);

      const rarity = Rarity.rollRarity(topicId, period, weights);
      if (rarity === "nothing") return; // most common case: no treasure, no toast.

      // Deterministic selector for which treasure within the tier: reuse the hash on a
      // slightly different key so it's independent of the rarity roll.
      const selector = Rarity.fnv1a(topicId + "|" + period + "|pick");
      const treasure = Catalog.pickTreasure(rarity, selector);
      if (!treasure) return; // tier had no entries (shouldn't happen) -> fail-safe.

      // "Ancient" mark (B-016, payoff #2): treasures found on year-old+ topics are special.
      const ancient = ageTier === "ancient";

      const item = {
        id: topicId + ":" + period,
        key: treasure.key,
        name: treasure.name,
        flavor: treasure.flavor || null,
        rarity: treasure.rarity,
        icon: treasure.icon,
        ancient: ancient,
        ageTier: ageTier,
        topicId: topicId,
        period: period,
        claimedAt: new Date().toISOString(),
      };

      const added = await Storage.addAward(item, topicId, period);
      if (added) showToast(item);
    } catch (e) {
      // Never let an error surface to the page. Fail safe: no award, no toast.
    }
  }

  const RARITY_LABEL = {
    legendary: "OTF History",
    rare: "Deep Lore",
    uncommon: "Touch Grass Moments",
    common: "Skill Issues",
  };

  /** Centered modal toast with a dimmed backdrop. Decoration only; no persistent page
   * state (ADR-0001). Auto-dismisses, and a click anywhere dismisses early. */
  function showToast(item) {
    const overlay = document.createElement("div");
    overlay.className = "cth-overlay";

    const toast = document.createElement("div");
    toast.className =
      "cth-toast cth-toast--" + item.rarity + (item.ancient ? " cth-toast--ancient" : "");
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");

    const rarityLabel = (item.ancient ? "Ancient " : "") + (RARITY_LABEL[item.rarity] || capitalize(item.rarity));

    // Rarity label
    const labelEl = document.createElement("span");
    labelEl.className = "cth-toast__rarity";
    labelEl.textContent = rarityLabel;
    toast.appendChild(labelEl);

    // Icon — image if asset exists, emoji fallback
    const iconEl = document.createElement("span");
    iconEl.className = "cth-toast__icon";
    iconEl.setAttribute("aria-hidden", "true");

    const imgUrl = chrome.runtime.getURL("assets/treasures/" + item.key + ".png");
    const imgEl = document.createElement("img");
    imgEl.src = imgUrl;
    imgEl.alt = "";
    imgEl.className = "cth-toast__img";
    imgEl.onerror = function () {
      // No asset for this item yet — fall back to emoji.
      iconEl.removeChild(imgEl);
      iconEl.textContent = item.icon;
    };
    iconEl.appendChild(imgEl);
    toast.appendChild(iconEl);

    // Name + flavor text
    const bodyEl = document.createElement("span");
    bodyEl.className = "cth-toast__body";

    const nameEl = document.createElement("span");
    nameEl.className = "cth-toast__name";
    nameEl.textContent = item.name;
    bodyEl.appendChild(nameEl);

    if (item.flavor) {
      const flavorEl = document.createElement("span");
      flavorEl.className = "cth-toast__flavor";
      flavorEl.textContent = item.flavor;
      bodyEl.appendChild(flavorEl);
    }

    toast.appendChild(bodyEl);

    // For rare/legendary, show a dismiss hint since there's no auto-dismiss.
    if (item.rarity === "rare" || item.rarity === "legendary") {
      const hint = document.createElement("span");
      hint.className = "cth-toast__hint";
      hint.textContent = "tap to close";
      toast.appendChild(hint);
    }

    // Legendary: inject particles + fireworks into the DOM.
    if (item.rarity === "legendary") {
      // 8 particle dots inside the card.
      for (var p = 0; p < 8; p++) {
        var particle = document.createElement("span");
        particle.className = "cth-particle";
        toast.appendChild(particle);
      }

      // 3 firework bursts placed around the card after entrance.
      var fwPositions = [
        { top: "15%",  left: "5%"  },
        { top: "10%",  left: "70%" },
        { top: "60%",  left: "75%" },
      ];
      setTimeout(function () {
        fwPositions.forEach(function (pos) {
          var fw = document.createElement("div");
          fw.className = "cth-firework";
          fw.style.top  = pos.top;
          fw.style.left = pos.left;
          for (var r = 0; r < 3; r++) {
            var ring = document.createElement("div");
            ring.className = "cth-firework__ring";
            fw.appendChild(ring);
          }
          overlay.appendChild(fw);
          setTimeout(function (el) { el.remove(); }, 900, fw);
        });
      }, 400);
    }

    overlay.appendChild(toast);
    document.body.appendChild(overlay);

    requestAnimationFrame(function () {
      overlay.classList.add("cth-overlay--visible");
    });

    let dismissed = false;
    function dismiss() {
      if (dismissed) return;
      dismissed = true;
      overlay.classList.remove("cth-overlay--visible");
      overlay.addEventListener("transitionend", function () {
        overlay.remove();
      });
      setTimeout(function () {
        overlay.remove();
      }, 600);
    }

    // Click anywhere to dismiss.
    overlay.addEventListener("click", dismiss);

    // Auto-dismiss only for common and uncommon.
    if (item.rarity === "common" || item.rarity === "uncommon") {
      setTimeout(dismiss, 6000);
    }
  }

  function capitalize(s) {
    return String(s).charAt(0).toUpperCase() + String(s).slice(1);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      }[c];
    });
  }
})();
